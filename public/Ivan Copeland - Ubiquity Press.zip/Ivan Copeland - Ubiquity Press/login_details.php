<?php
function login_details(){

  $login_details = array(
    "servername" => "192.168.10.10",
    "username" => "homestead",
    "password" => "secret",
    "db" => "Rich-and-Smart-SQL-DB-Development",


  );


  return $login_details;



}
?>
